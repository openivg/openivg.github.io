## InViG 500K

### Annotation

Each line in the annotation file includes keys:

```
"filename": the image file which this annotation is for.
"width": image width
"height": image height
"ann":
    "bboxes": a list of bounding boxes from SAM dataset
    "ref_exp": the initial instruction
    "questions": questions to disambiguate
    "answers": the corresponding answers
    "ref_bboxes": the box that the dialog is about
"id": the unique id of this annotation
```


### Images

Images are compressed using zip into blocks. To uncompress, you need to:

```console
zip -F invig500k.zip --out invig500k_full.zip
unzip invig500k_full.zip
```

The script will firstly concat all blocks to a big file, and then uncompress it.
The big file will be about 230GB.

## InViG 21K

### Annotation

Mostly, it is similar to InViG 500K. Some differences are listed here.

For training set ``invig21k_train_anns.jsonl``:

```
"invig_label_id": the global unique id for the whole InViG 21K dataset
"id": the unique id in this split
```

For validation set ``invig21k_valid_anns.jsonl`` and test set ``invig21k_test_anns.jsonl``:

```
"ann": 
    "question_candidates": the candidates for all questions
    "answer_candidates": the candidates for all answers
    # Each question or answer has 30 incorrect candidates.
```